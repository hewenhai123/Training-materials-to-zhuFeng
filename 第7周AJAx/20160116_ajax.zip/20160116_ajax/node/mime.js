/**
 * Created by 银鹏 on 2016/1/16.
 */
exports.types = {
    "css": "text/css",
    "html": "text/html",
    "jpeg": "image/jpeg",
    "jpg": "image/jpeg",
    "js": "text/javascript",
    "json": "application/json",
    "png": "image/png",
    "xml": "text/xml"
};