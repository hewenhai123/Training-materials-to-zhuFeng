/**
 * Created by 银鹏 on 2016/3/5.
 */
var http=require('http');
http.createServer(function(request,response){

});
http.listen(8080,function(){
   console.log('done');
});