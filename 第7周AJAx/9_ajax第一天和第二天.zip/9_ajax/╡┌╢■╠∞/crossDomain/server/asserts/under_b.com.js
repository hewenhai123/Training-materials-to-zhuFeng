/**
 * Created by 银鹏 on 2016/3/6.
 */
//console.log('这是b.com下的js文件，如果你看到这句话，说明js成功执行了')
var a = [{id: 1, name: '张三'}, {id: 2, name: '李四'}, {id: 3, name: '马六'}];