/**
 * Created by 银鹏 on 2016/3/6.
 */
var list = [
    {
        id: 1,
        name: '隔壁老王',
        age: '18'
    },
    {
        id: 2,
        name: '钻石王老五',
        age: 50
    },
    {
        id: 3,
        name: '拆迁户',
        age: 30
    },
    {
        id: 4,
        name: '隔壁老耿',
        age: 23
    }
];

module.exports = list;